import { sendMagicLink } from "@/app/actions";
import { createClient } from "@/lib/supabase/server";
import { redirect } from "next/navigation";

type Props = { searchParams: Promise<{ sent?: string; error?: string }> };

export default async function LoginPage({ searchParams }: Props) {
  const params = await searchParams;
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (user) redirect("/");
  const errors: Record<string, string> = {
    invalid_email: "이메일 주소를 확인해 주세요.",
    send_failed: "로그인 링크를 보내지 못했습니다. Supabase 설정을 확인해 주세요.",
    auth_callback: "로그인 링크가 만료되었거나 유효하지 않습니다. 다시 요청해 주세요."
  };
  return (
    <main className="loginpage">
      <section className="loginbox">
        <div className="brandmark">KAIROX</div>
        <div className="eyebrow">MANAGEMENT SYSTEM</div>
        <h1>안전한 이메일 로그인</h1>
        <p>등록된 직원 이메일로 일회용 로그인 링크를 보내드립니다. 초대받지 않은 계정은 로그인할 수 없습니다.</p>
        {params.sent === "1" && <div className="success">등록된 이메일이라면 로그인 링크가 발송됩니다. 받은 편지함과 스팸함을 확인해 주세요.</div>}
        {params.error && <div className="error">{errors[params.error] || "로그인에 실패했습니다. 다시 시도해 주세요."}</div>}
        <form action={sendMagicLink}>
          <label className="field">업무용 이메일
            <input name="email" type="email" placeholder="name@company.com" autoComplete="email" required />
          </label>
          <button className="primary" type="submit">보안 로그인 링크 받기</button>
        </form>
        <p style={{fontSize:12,marginTop:22}}>관리자 참조 이메일: Ceo@emdadkorea.com<br/>계정은 관리자가 먼저 등록해야 합니다.</p>
      </section>
    </main>
  );
}
