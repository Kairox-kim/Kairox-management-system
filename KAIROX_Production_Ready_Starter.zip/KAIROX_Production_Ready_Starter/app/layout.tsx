import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "KAIROX Management System",
  description: "Private KAIROX operations portal for vehicles, parts, purchasing, cash and export logistics.",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ko">
      <body>{children}</body>
    </html>
  );
}
