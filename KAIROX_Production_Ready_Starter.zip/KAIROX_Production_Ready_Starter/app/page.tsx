import { redirect } from "next/navigation";
import { createClient } from "@/lib/supabase/server";
import { signOut } from "@/app/actions";
import Portal from "./portal";

export default async function Home() {
  const supabase = await createClient();
  const { data: { user } } = await supabase.auth.getUser();
  if (!user) redirect("/login");

  const { data: profile } = await supabase
    .from("profiles")
    .select("full_name, role, preferred_language, is_active")
    .eq("id", user.id)
    .maybeSingle();

  if (!profile || profile.is_active === false) {
    await supabase.auth.signOut();
    redirect("/login?error=not_authorized");
  }

  return <Portal email={user.email || ""} fullName={profile.full_name || ""} role={profile.role || "staff"} language={profile.preferred_language || "ko"} signOutAction={signOut} />;
}
