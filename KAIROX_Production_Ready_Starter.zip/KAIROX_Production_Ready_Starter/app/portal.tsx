"use client";

import { useMemo, useState } from "react";

type Lang = "ko" | "ar";
type Props = { email: string; fullName: string; role: string; language: string; signOutAction: () => Promise<void> };
type Section = "dashboard" | "purchases" | "vehicles" | "parts" | "cash" | "exports" | "suppliers" | "reports";

const copy = {
  ko: {
    dashboard:"대시보드", purchases:"구매 관리", vehicles:"차량 재고", parts:"부품 재고", cash:"금고 및 회계", exports:"수출 및 물류", suppliers:"공급업체", reports:"보고서 및 문서",
    eyebrow:"KAIROX OPERATIONS", overview:"운영 현황", welcome:"운영을 명확하게, 관리를 안전하게.", intro:"차량·부품 재고, 구매, 현금 흐름, 수출 업무를 한 곳에서 관리하는 KAIROX 운영 포털입니다.",
    cars:"등록 차량", partsCount:"부품 품목", purchasesCount:"구매 기록", cashCount:"승인된 회계 기록", quick:"업무 바로가기", recent:"최근 활동", secure:"보안 상태", secureText:"인증된 사용자 전용 영역입니다. 데이터 접근 권한은 서버와 데이터베이스 정책에서 확인됩니다.",
    signout:"로그아웃", search:"검색", add:"새 기록", export:"CSV 내보내기", noData:"아직 등록된 데이터가 없습니다.", soon:"이 모듈의 실제 데이터 입력 화면은 데이터베이스 연결과 검증 후 활성화됩니다.",
    reference:"관리자 참조", role:"역할", admin:"관리자", staff:"직원", language:"언어", languageLabel:"한국어", ready:"운영 포털", disclaimer:"프로덕션 데이터베이스 연결 전까지는 실데이터를 표시하지 않습니다."
  },
  ar: {
    dashboard:"لوحة التحكم", purchases:"المشتريات", vehicles:"مخزون السيارات", parts:"مخزون القطع", cash:"الصندوق والحسابات", exports:"التصدير والشحن", suppliers:"الموردون", reports:"التقارير والمستندات",
    eyebrow:"عمليات KAIROX", overview:"نظرة عامة", welcome:"إدارة واضحة. عمليات أكثر أمانًا.", intro:"بوابة KAIROX الموحدة لإدارة السيارات وقطع الغيار والمشتريات والصندوق والتصدير والشحن.",
    cars:"السيارات المسجلة", partsCount:"أصناف القطع", purchasesCount:"سجلات المشتريات", cashCount:"القيود المحاسبية المعتمدة", quick:"الوصول السريع", recent:"النشاط الأخير", secure:"حالة الأمان", secureText:"هذه المنطقة للمستخدمين المصادق عليهم فقط. تُراجع صلاحيات البيانات على الخادم وفي قاعدة البيانات.",
    signout:"تسجيل الخروج", search:"بحث", add:"سجل جديد", export:"تصدير CSV", noData:"لا توجد بيانات مسجلة بعد.", soon:"سيتم تفعيل شاشة إدخال البيانات الفعلية لهذا القسم بعد ربط قاعدة البيانات والتحقق منها.",
    reference:"البريد الإداري المرجعي", role:"الصلاحية", admin:"مدير", staff:"موظف", language:"اللغة", languageLabel:"العربية", ready:"بوابة التشغيل", disclaimer:"لن تظهر بيانات فعلية قبل ربط قاعدة بيانات الإنتاج."
  }
};

const sections: Section[] = ["dashboard","purchases","vehicles","parts","cash","exports","suppliers","reports"];
const icons: Record<Section,string> = {dashboard:"◈",purchases:"↗",vehicles:"▣",parts:"▦",cash:"₩",exports:"⇄",suppliers:"♧",reports:"▤"};

export default function Portal({ email, fullName, role, language, signOutAction }: Props) {
  const [lang, setLang] = useState<Lang>(language === "ar" ? "ar" : "ko");
  const [active, setActive] = useState<Section>("dashboard");
  const t = copy[lang];
  const rtl = lang === "ar";
  const title = t[active];
  const labels = useMemo(() => sections.map((s) => ({ id:s, name:t[s] })), [t]);
  return (
    <div className="shell" dir={rtl ? "rtl" : "ltr"} lang={lang}>
      <aside className="sidebar">
        <div className="brand"><div className="brandmark">KAIROX</div><small>{t.ready}</small></div>
        <nav className="nav" aria-label="Main navigation">
          {labels.map((item) => <button key={item.id} className={active===item.id?"active":""} onClick={() => setActive(item.id)}><span>{icons[item.id]}</span>{item.name}</button>)}
        </nav>
        <div className="sidefoot">PRIVATE OPERATIONS PORTAL<br/>© KAIROX Management System</div>
      </aside>
      <main className="main">
        <header className="topbar">
          <div><div className="eyebrow">{t.eyebrow}</div><h1>{active==="dashboard"?t.overview:title}</h1></div>
          <div className="topactions">
            <button className="lang" onClick={() => setLang(rtl?"ko":"ar")}>{rtl?"한국어":"العربية"}</button>
            <div style={{textAlign:rtl?"left":"right",maxWidth:190}}><strong style={{fontSize:12,display:"block",overflowWrap:"anywhere"}}>{fullName || email}</strong><span className="muted">{role==="admin"?t.admin:t.staff}</span></div>
            <form action={signOutAction}><button className="outline" type="submit">{t.signout}</button></form>
          </div>
        </header>
        <div className="content">
          {active==="dashboard" ? <>
            <section className="welcome"><div><div className="eyebrow gold">{t.eyebrow}</div><h2>{t.welcome}</h2><p>{t.intro}</p></div><span className="pill">SECURE PORTAL</span></section>
            <div className="stats">
              {[t.cars,t.partsCount,t.purchasesCount,t.cashCount].map((label,i)=><section className="stat" key={label}><div className="statlabel">{label}</div><div className="statnum">—</div><div className="statfoot">{t.disclaimer}</div></section>)}
            </div>
            <div className="grid2">
              <section className="panel"><div className="sectionhead"><div><h2>{t.quick}</h2><p>{lang==="ko"?"필요한 업무 영역으로 이동하세요.":"انتقل إلى القسم المطلوب."}</p></div></div>
                <div className="list">{sections.filter(s=>s!=="dashboard").map(s=><button key={s} className="listrow" style={{border:0,background:"transparent",width:"100%",textAlign:rtl?"right":"left",cursor:"pointer"}} onClick={()=>setActive(s)}><span><strong>{t[s]}</strong><span className="muted" style={{display:"block",marginTop:5}}>{t.soon}</span></span><span>→</span></button>)}</div>
              </section>
              <section className="panel"><div className="sectionhead"><div><h2>{t.secure}</h2><p>{t.recent}</p></div><span className="pill">{lang==="ko"?"인증됨":"تم التحقق"}</span></div>
                <p className="muted" style={{lineHeight:1.9}}>{t.secureText}</p>
                <div className="notice">{t.reference}: <strong>Ceo@emdadkorea.com</strong><br/>{t.disclaimer}</div>
              </section>
            </div>
          </> : <>
            <div className="sectionhead"><div><h2>{title}</h2><p>{t.soon}</p></div><span className="pill gray">{lang==="ko"?"설정 단계":"مرحلة الإعداد"}</span></div>
            <div className="panel"><div className="empty"><div style={{fontSize:32,marginBottom:12}}>{icons[active]}</div><strong>{t.noData}</strong><p className="muted">{t.soon}</p></div></div>
          </>}
          <div className="footer">KAIROX Management System · Private business data · No sales module</div>
        </div>
      </main>
    </div>
  );
}
