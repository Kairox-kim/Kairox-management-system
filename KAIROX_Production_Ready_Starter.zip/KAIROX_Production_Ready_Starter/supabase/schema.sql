-- KAIROX Management System production schema
-- Run in Supabase SQL Editor only after creating a new project and reviewing this file.
create extension if not exists pgcrypto;

create type public.app_role as enum ('admin', 'manager', 'staff', 'viewer');
create type public.vehicle_status as enum ('in_stock', 'reserved', 'export_processing', 'shipped', 'sold', 'on_hold');
create type public.purchase_status as enum ('draft', 'pending', 'received', 'cancelled');
create type public.cash_status as enum ('draft', 'pending', 'approved', 'reversed');
create type public.stock_movement_kind as enum ('receipt', 'issue', 'reserve', 'release', 'adjustment', 'reversal');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  email text not null,
  full_name text,
  role public.app_role not null default 'staff',
  preferred_language text not null default 'ko' check (preferred_language in ('ko','ar')),
  is_active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.suppliers (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  contact_name text,
  email text,
  phone text,
  address text,
  notes text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.vehicles (
  id uuid primary key default gen_random_uuid(),
  vin text not null unique,
  make text not null,
  model text not null,
  model_year int check (model_year between 1950 and 2100),
  fuel_type text,
  transmission text,
  mileage_km bigint check (mileage_km >= 0),
  color text,
  cost numeric(14,2) not null default 0 check (cost >= 0),
  currency char(3) not null default 'KRW',
  supplier_id uuid references public.suppliers(id),
  location text,
  status public.vehicle_status not null default 'in_stock',
  export_reference text,
  notes text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.parts (
  id uuid primary key default gen_random_uuid(),
  sku text not null unique,
  name text not null,
  category text,
  oem_number text,
  compatibility text,
  condition text,
  quantity integer not null default 0 check (quantity >= 0),
  reserved_quantity integer not null default 0 check (reserved_quantity >= 0 and reserved_quantity <= quantity),
  reorder_level integer not null default 0 check (reorder_level >= 0),
  unit_cost numeric(14,2) not null default 0 check (unit_cost >= 0),
  currency char(3) not null default 'KRW',
  supplier_id uuid references public.suppliers(id),
  location text,
  notes text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.purchases (
  id uuid primary key default gen_random_uuid(),
  reference text not null unique,
  supplier_id uuid references public.suppliers(id),
  item_type text not null check (item_type in ('vehicle','part','other')),
  status public.purchase_status not null default 'draft',
  subtotal numeric(14,2) not null default 0 check (subtotal >= 0),
  tax numeric(14,2) not null default 0 check (tax >= 0),
  total numeric(14,2) generated always as (subtotal + tax) stored,
  currency char(3) not null default 'KRW',
  ordered_at date,
  received_at timestamptz,
  notes text,
  created_by uuid references auth.users(id),
  received_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.cash_entries (
  id uuid primary key default gen_random_uuid(),
  reference text not null unique,
  direction text not null check (direction in ('in','out')),
  category text not null,
  amount numeric(14,2) not null check (amount > 0),
  currency char(3) not null default 'KRW',
  status public.cash_status not null default 'draft',
  occurred_at timestamptz not null default now(),
  description text,
  related_purchase_id uuid references public.purchases(id),
  created_by uuid references auth.users(id),
  approved_by uuid references auth.users(id),
  approved_at timestamptz,
  reversal_of uuid references public.cash_entries(id),
  idempotency_key text not null unique,
  created_at timestamptz not null default now()
);

create table public.export_shipments (
  id uuid primary key default gen_random_uuid(),
  reference text not null unique,
  vehicle_id uuid references public.vehicles(id),
  destination_country text not null,
  buyer_reference text,
  shipping_company text,
  booking_number text,
  vessel_name text,
  port_of_loading text,
  port_of_destination text,
  etd date,
  eta date,
  status text not null default 'preparing' check (status in ('preparing','booked','loaded','departed','arrived','cleared','completed','cancelled')),
  document_notes text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.stock_movements (
  id uuid primary key default gen_random_uuid(),
  item_type text not null check (item_type in ('vehicle','part')),
  vehicle_id uuid references public.vehicles(id),
  part_id uuid references public.parts(id),
  kind public.stock_movement_kind not null,
  quantity integer not null check (quantity > 0),
  reference text not null,
  idempotency_key text not null unique,
  notes text,
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  check ((item_type='vehicle' and vehicle_id is not null and part_id is null) or (item_type='part' and part_id is not null and vehicle_id is null))
);

create table public.audit_log (
  id bigint generated always as identity primary key,
  actor_id uuid references auth.users(id),
  action text not null,
  table_name text not null,
  record_id text,
  request_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index vehicles_status_idx on public.vehicles(status);
create index vehicles_supplier_idx on public.vehicles(supplier_id);
create index parts_category_idx on public.parts(category);
create index parts_supplier_idx on public.parts(supplier_id);
create index purchases_status_idx on public.purchases(status);
create index cash_status_idx on public.cash_entries(status);
create index shipments_status_idx on public.export_shipments(status);
create index audit_log_created_idx on public.audit_log(created_at desc);

create or replace function public.current_app_role()
returns public.app_role
language sql stable security definer
set search_path = ''
as $$
  select role from public.profiles
  where id = (select auth.uid()) and is_active = true
$$;

create or replace function public.is_active_user()
returns boolean
language sql stable security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles
    where id = (select auth.uid()) and is_active = true
  )
$$;

create or replace function public.has_any_role(allowed public.app_role[])
returns boolean
language sql stable security definer
set search_path = ''
as $$
  select exists (
    select 1 from public.profiles
    where id = (select auth.uid())
      and is_active = true
      and role = any(allowed)
  )
$$;

alter table public.profiles enable row level security;
alter table public.suppliers enable row level security;
alter table public.vehicles enable row level security;
alter table public.parts enable row level security;
alter table public.purchases enable row level security;
alter table public.cash_entries enable row level security;
alter table public.export_shipments enable row level security;
alter table public.stock_movements enable row level security;
alter table public.audit_log enable row level security;

create policy "profiles self or admin read" on public.profiles for select to authenticated
using (id = (select auth.uid()) or public.has_any_role(array['admin']::public.app_role[]));
create policy "admins manage profiles" on public.profiles for all to authenticated
using (public.has_any_role(array['admin']::public.app_role[]))
with check (public.has_any_role(array['admin']::public.app_role[]));

create policy "active staff read suppliers" on public.suppliers for select to authenticated using (public.is_active_user());
create policy "managers manage suppliers" on public.suppliers for all to authenticated
using (public.has_any_role(array['admin','manager']::public.app_role[]))
with check (public.has_any_role(array['admin','manager']::public.app_role[]));

create policy "active staff read vehicles" on public.vehicles for select to authenticated using (public.is_active_user());
create policy "managers manage vehicles" on public.vehicles for all to authenticated
using (public.has_any_role(array['admin','manager']::public.app_role[]))
with check (public.has_any_role(array['admin','manager']::public.app_role[]));

create policy "active staff read parts" on public.parts for select to authenticated using (public.is_active_user());
create policy "managers manage parts" on public.parts for all to authenticated
using (public.has_any_role(array['admin','manager']::public.app_role[]))
with check (public.has_any_role(array['admin','manager']::public.app_role[]));

create policy "active staff read purchases" on public.purchases for select to authenticated using (public.is_active_user());
create policy "managers create purchases" on public.purchases for insert to authenticated
with check (public.has_any_role(array['admin','manager']::public.app_role[]));
create policy "managers update draft purchases" on public.purchases for update to authenticated
using (status in ('draft','pending') and public.has_any_role(array['admin','manager']::public.app_role[]))
with check (public.has_any_role(array['admin','manager']::public.app_role[]));

create policy "active staff read cash entries" on public.cash_entries for select to authenticated using (public.has_any_role(array['admin','manager','viewer']::public.app_role[]));
create policy "managers create draft cash entries" on public.cash_entries for insert to authenticated
with check (status in ('draft','pending') and public.has_any_role(array['admin','manager']::public.app_role[]));
create policy "admin manager update unapproved cash" on public.cash_entries for update to authenticated
using (status in ('draft','pending') and public.has_any_role(array['admin','manager']::public.app_role[]))
with check (public.has_any_role(array['admin','manager']::public.app_role[]));

create policy "active staff read shipments" on public.export_shipments for select to authenticated using (public.is_active_user());
create policy "managers manage shipments" on public.export_shipments for all to authenticated
using (public.has_any_role(array['admin','manager']::public.app_role[]))
with check (public.has_any_role(array['admin','manager']::public.app_role[]));

create policy "active staff read stock movements" on public.stock_movements for select to authenticated using (public.is_active_user());
create policy "managers insert stock movements" on public.stock_movements for insert to authenticated
with check (public.has_any_role(array['admin','manager']::public.app_role[]));

create policy "admins read audit log" on public.audit_log for select to authenticated
using (public.has_any_role(array['admin']::public.app_role[]));
create policy "active users write audit log" on public.audit_log for insert to authenticated
with check (actor_id = (select auth.uid()) and public.is_active_user());

-- Invite-only guard: users cannot sign themselves up from the app because signInWithOtp uses shouldCreateUser=false.
-- Create/invite users from Supabase Dashboard or a future server-only admin endpoint using a secret key.
-- Create the first profile manually after inviting the owner. Do not expose service_role keys in the browser.
