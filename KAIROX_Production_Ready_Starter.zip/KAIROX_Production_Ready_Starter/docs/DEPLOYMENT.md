# KAIROX Web Portal — deployment guide

## What this starter is
This is a cloud-deployable Next.js starter with email magic-link authentication wiring, a bilingual Korean/Arabic portal shell, Supabase schema/RLS, and no sales module. It is not yet a finished business application: CRUD screens, stock/cash transactional workflows, private document upload, staff invitation UI, audit triggers, and automated tests still need implementation and verification.

## 1. Create the managed services
1. Create a Supabase project at https://supabase.com/dashboard.
2. In SQL Editor, review and run `supabase/schema.sql`.
3. In Project Settings → API, copy the project URL and publishable/anon key.
4. In Authentication → URL Configuration, set the Site URL to your eventual Vercel deployment URL (initially it can be the generated `*.vercel.app` address). Add redirect URL `https://YOUR-DEPLOYMENT.vercel.app/auth/callback` and local `http://localhost:3000/auth/callback`.
5. In Authentication → Providers → Email, enable email OTP/magic links and configure email delivery. For a real company portal, configure a verified sender/domain and production SMTP if required by your provider/plan.
6. Set environment variables in Vercel Project Settings → Environment Variables:
   - `NEXT_PUBLIC_SUPABASE_URL`
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY`
   - `NEXT_PUBLIC_SITE_URL` = the exact deployment origin, e.g. `https://your-project.vercel.app`
7. Import this folder into a GitHub repository you control, then import that repository into Vercel. Use the default Next.js build settings and deploy.
8. After deployment, update Supabase Site URL and redirect allow-list to the final Vercel URL, then test a real magic link on mobile and desktop.

## 2. Owner/admin bootstrap — must be done deliberately
- The reference email `Ceo@emdadkorea.com` is a configuration target only; this project cannot verify that you own/control it.
- In Supabase Authentication, invite the owner email. After the user is created, insert a matching profile row using the Auth user UUID:
  ```sql
  insert into public.profiles (id, email, full_name, role, preferred_language, is_active)
  values ('AUTH_USER_UUID', 'Ceo@emdadkorea.com', 'KAIROX Administrator', 'admin', 'ko', true);
  ```
- Replace `AUTH_USER_UUID` with the actual UUID from Supabase Auth Users. Do not guess it.
- Keep public sign-up disabled. The application uses `shouldCreateUser: false` to prevent unknown email addresses from self-registering.
- Add staff from Supabase Auth dashboard and insert profile rows with the intended role. A polished in-portal invite/role management screen is not implemented yet.

## 3. Local run
Requires Node.js 20.9+.
```bash
cp .env.example .env.local
# edit .env.local with your Supabase values
npm install
npm run dev
```
Open http://localhost:3000. A production build can be checked with `npm run build`.

## 4. Important production gaps to close before handling real money or inventory
- Implement server-side mutations with schema validation, authorization and transactions.
- Implement receipt confirmation so stock changes only after confirmed receipt.
- Implement cash approval so cash totals change only after approval; approved entries are reversed, never deleted.
- Implement idempotency and audit logging for every mutation.
- Implement secure private storage buckets and signed URLs for documents/photos.
- Add role-specific field and action permissions, admin staff management, passwordless email rate limits and CAPTCHA/abuse controls if needed.
- Add tests (RLS integration, role access, idempotency, inventory and cash invariants), backups/retention, monitoring and restore rehearsal.
- Review legal/accounting requirements for the countries in which KAIROX operates.
- Do not use this starter as the sole source of truth for financial operations until the above is completed and tested.

## 5. Deployment safety
- Never commit `.env.local`, access tokens, SMTP passwords, or Supabase service-role/secret keys.
- Use only publishable/anon key in `NEXT_PUBLIC_*`; RLS is mandatory.
- Use HTTPS, verified sender domain, MFA for provider accounts, least privilege, and regular backups.
